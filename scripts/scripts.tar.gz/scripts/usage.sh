#cleanup
sleep 5

sudo systemctl start datacollector.service

sleep 10

COLLECTOR=$(ps -ef | awk '$11=="-r=collector" {print $2}')
sleep 5

NSHELPER=$(ps -ef | awk '$10=="mnt" {print $2}')

echo $COLLECTOR
echo $NSHELPER


ps -ef | grep datacollector

# make sure collector/nshelper is running
ps -ef | grep -q 'collector'
if [ $? -eq 1 ]
then
        echo "Agent failed to start, aborting test"
        exit 1
fi

ps -ef | grep -q 'mnt'
if [ $? -eq 1 ]
then
        echo "nshelper failed to start, aborting test"
#        exit 1
fi

psrecord $COLLECTOR --interval 3 --log agent_usage.txt --duration 4200 --include-children &

#psrecord $NSHELPER --interval 3 --log nshelper_usage.txt --duration 4200 &

psrecord $COLLECTOR --interval 3 --log collector_usage.txt --duration 4200 &
sleep 4220



sudo systemctl stop datacollector.service

